__asm__(".code16gcc\n");
extern int myputc(char ch);
