__asm__(".code16gcc\n");
extern int cursorleft();
extern int cursorright();
extern int ascandsyscode();
char _sysscancode;
#include "myos.h"
